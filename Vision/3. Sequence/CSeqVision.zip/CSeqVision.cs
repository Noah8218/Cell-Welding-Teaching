﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Matrox.MatroxImagingLibrary;

namespace IntelligentFactory
{
    public class CSeqVision
    {
        private IGlobal Global = IGlobal.Instance;
        public EventHandler<InspResultArgs> EventInspResult;

        #region Thread
        public IThreadStatus ThreadStatusVision = new IThreadStatus();

        public void StartThreadVision()
        {
            Thread t = new Thread(new ParameterizedThreadStart(ThreadVision));
            t.Start(ThreadStatusVision);
        }

        public void ResetThreadVision()
        {
            ThreadStatusVision.End();
        }

        public void StopThreadVision()
        {
            if (!ThreadStatusVision.IsExit())
            {
                ThreadStatusVision.Stop(100);
            }

            ResetThreadVision();
        }

        private void ThreadVision(object ob)
        {
            IThreadStatus ThreadStatus = (IThreadStatus)ob;

            ThreadStatus.Start("Vision Inspection");
            Logger.WriteLog(LOG.Normal, "Vision Inspection");

            try
            {
                while (!ThreadStatus.IsExit())
                {
                    if (Global.iData.GrabQueue.Count > 0)
                    {
                        int START_TIME = Environment.TickCount;

                        if (Global.iData.GrabQueue.TryDequeue(out CGrabBuffer GrabBuffer))
                        {
                            if (Global.iSystem.Mode != ISystem.MODE.AUTO) continue;

                            if (GrabBuffer != null)
                            {
                                CGrabberMatroxSolios Grabber = Global.iDevice.CAMERA;
                                MIL_ID ImageSource = GrabBuffer.ImageGrab;

                                string strBCR = "";

                               
                                List<IVT_CODE_RESULT> Results_BCR = IVT_MDataMatrix.Run(Grabber.MIL_System, Grabber.MIL_Display, ImageSource, Global.iSystem.Recipe.ROI_BCR, GrabBuffer.Handle);
                                Thread.Sleep(1);
                                List<IVT_MEAS_RESULT> Results_EDGE = new List<IVT_MEAS_RESULT>();
                                Thread.Sleep(1);

                                int T_START_TIME = Environment.TickCount;

                                try
                                {
                                    CIVT_LineGuage LineGuage_Top = new CIVT_LineGuage("TOP_EDGE");
                                    LineGuage_Top.SetProperty(Global.iData.Property_LineGuage_Top);
                                    LineGuage_Top.SetSourceImage(ImageSource);
                                    LineGuage_Top.Run();

                                    CIVT_CVMatching Matching_Masking = new CIVT_CVMatching("MATCHING_MASKING");
                                    Matching_Masking.SetProperty(Global.iData.Property_Matching_Masking);
                                    Matching_Masking.SetSourceImage(ImageSource);
                                    Matching_Masking.Run();

                                    List<OpenCvSharp.Rect> Masking = new List<OpenCvSharp.Rect>();
                                    for (int i = 0; i < Matching_Masking.Results.Count; i++)
                                    {
                                        Masking.Add(CConverter.ScreenCVRectToLogicalCVRect(Matching_Masking.Results[i].Bounding, (float)Global.iData.Property_Matching_Masking.MAGNIFIATION, (float)Global.iData.Property_Matching_Masking.MAGNIFIATION));
                                    }

                                    CIVT_LineGuage LineGuage_Tubing = new CIVT_LineGuage("TUBING_EDGE");
                                    LineGuage_Tubing.SetProperty(Global.iData.Property_LineGuage_Tubing);
                                    LineGuage_Tubing.SetSourceImage(ImageSource);

                                    LineGuage_Tubing.Run(Masking);

                                    System.Drawing.Point ptStart = new System.Drawing.Point();
                                    bool bFoundFirst = false;

                                    if (LineGuage_Top.Results.Count > 0) LineGuage_Top.Results = LineGuage_Top.Results.OrderBy(p => p.MeasPos.Y).ToList();
                                    if (LineGuage_Top.Results.Count < 2)
                                    {
                                        Logger.WriteLog(LOG.AbNormal, "[FAILED] Inspection Fail");

                                        if (EventInspResult != null)
                                        {
                                            EventInspResult(this, new InspResultArgs(ImageSource, GrabBuffer.Index, strBCR, Results_BCR, Results_EDGE));
                                        }
                                        //CUtil.ShowMessageBox("ALARM", "Can't Find the Edge of Top");
                                        continue;
                                    }

                                    Line TopFittedLine = new Line(CConverter.PointToCVPoint(LineGuage_Top.Results[0].MeasPos), CConverter.PointToCVPoint(LineGuage_Top.Results[LineGuage_Top.Results.Count - 1].MeasPos));

                                    if (LineGuage_Tubing.Results.Count > 0)
                                    {
                                        for (int i = 0; i < LineGuage_Tubing.Results.Count; i++)
                                        {
                                            if (bFoundFirst == false
                                                && LineGuage_Tubing.Results[i].MeasPos.X > LineGuage_Tubing.dAverageX - Global.iData.Property_LineGuage_Tubing.OUTFITTING
                                                && LineGuage_Tubing.Results[i].MeasPos.X < LineGuage_Tubing.dAverageX + Global.iData.Property_LineGuage_Tubing.OUTFITTING
                                                )
                                            {
                                                bFoundFirst = true;
                                                ptStart = new System.Drawing.Point(Global.iData.Property_LineGuage_Tubing.ROI.X + LineGuage_Tubing.Results[i].MeasPos.X, Global.iData.Property_LineGuage_Tubing.ROI.Y + LineGuage_Tubing.Results[i].MeasPos.Y);

                                                continue;
                                            }

                                            if (bFoundFirst)
                                            {
                                                if (i + 1 < LineGuage_Tubing.Results.Count)
                                                {
                                                    if (LineGuage_Tubing.Results[i].MeasPos.X > LineGuage_Tubing.dAverageX - Global.iData.Property_LineGuage_Tubing.OUTFITTING
                                                        && LineGuage_Tubing.Results[i].MeasPos.X < LineGuage_Tubing.dAverageX + Global.iData.Property_LineGuage_Tubing.OUTFITTING)
                                                    {
                                                        System.Drawing.Point ptEnd = new System.Drawing.Point(Global.iData.Property_LineGuage_Tubing.ROI.X + LineGuage_Tubing.Results[i].MeasPos.X, Global.iData.Property_LineGuage_Tubing.ROI.Y + LineGuage_Tubing.Results[i].MeasPos.Y);

                                                        double dDistance = IMath.GetDistanceLineToPoint(CConverter.PointToCVPoint(ptStart), TopFittedLine.Start, TopFittedLine.End, out OpenCvSharp.Point ptCloset);

                                                        ptCloset.X += Global.iData.Property_LineGuage_Top.ROI.X;

                                                        //g.DrawLine(new Pen(Color.Orange, 1), ptStart, CConverter.CVPointToPoint(ptCloset));

                                                        Results_EDGE.Add(new IVT_MEAS_RESULT(CConverter.CVPointToPoint(ptCloset), ptStart));

                                                        ptStart = ptEnd;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    //ImageDisplay.Save(Application.StartupPath + $"\\CAPTURE\\TESTSAVE_{DateTime.Now.ToString("yyMMdd_HHmmss")}_{GrabBuffer.Index}.bmp");
                                }
                                catch (Exception Desc)
                                {
                                    Logger.WriteLog(LOG.AbNormal, "[FAILED] Inspection Fail");

                                    if (EventInspResult != null)
                                    {
                                        EventInspResult(this, new InspResultArgs(ImageSource, GrabBuffer.Index, strBCR, Results_BCR, Results_EDGE));
                                    }

                                    Logger.WriteLog(LOG.AbNormal, "[FAILED] {0}/{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, Desc.Message);

                                    return;
                                }

                                if (EventInspResult != null)
                                {
                                    EventInspResult(this, new InspResultArgs(ImageSource, GrabBuffer.Index, strBCR, Results_BCR, Results_EDGE));
                                }
                            }
                        }

                        int nTaktTimems = Environment.TickCount - START_TIME;
                    }
                }
            }
            catch (Exception Desc)
            {
                Logger.WriteLog(LOG.AbNormal, "[FAILED] Inspection Fail");
                
                Logger.WriteLog(LOG.AbNormal, "[FAILED] {0}/{1}   Execption ==> {2}", MethodBase.GetCurrentMethod().ReflectedType.Name, MethodBase.GetCurrentMethod().Name, Desc.Message);
            }

        }
        #endregion
    }
}
